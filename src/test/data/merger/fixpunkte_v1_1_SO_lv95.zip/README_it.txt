Detailinformationen Kanton 
---------------------------

Thema:
    Punti fissi (Categoria 2)
Aktualisierungs-Zyklus:
    Wenn Nötig
Zeitstand (letzte Publikation):
    03.03.2025 04:22:12
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
